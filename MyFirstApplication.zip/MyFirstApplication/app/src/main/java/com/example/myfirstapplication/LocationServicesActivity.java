package com.example.myfirstapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class LocationServicesActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;

    private LocationManager locationManager;
    private LocationListener locationListener;

    private double latitude;
    private double longitude;

    private TextView textViewLatitude;
    private TextView textViewLongitude;
    private TextView textViewAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_location_services);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textViewLatitude = findViewById(R.id.textViewLatitude);
        textViewLongitude = findViewById(R.id.textViewLongitude);
        textViewAddress = findViewById(R.id.textViewAddress);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                showLocationAddress();
            }
        };

        if (hasLocationPermission()) {
            startLocationUpdates();
        } else {
            requestLocationPermission();
        }
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(
                this,
                new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                },
                REQUEST_PERMISSION
        );
    }

    private void startLocationUpdates() {
        if (!hasLocationPermission()) {
            return;
        }

        try {
            boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean networkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

            if (gpsEnabled) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        2000,
                        1,
                        locationListener,
                        Looper.getMainLooper()
                );

                Location gpsLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (gpsLocation != null) {
                    latitude = gpsLocation.getLatitude();
                    longitude = gpsLocation.getLongitude();
                    showLocationAddress();
                    return;
                }
            }

            if (networkEnabled) {
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        2000,
                        1,
                        locationListener,
                        Looper.getMainLooper()
                );

                Location networkLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (networkLocation != null) {
                    latitude = networkLocation.getLatitude();
                    longitude = networkLocation.getLongitude();
                    showLocationAddress();
                    return;
                }
            }

            textViewAddress.setText("Address: Waiting for location...");
        } catch (SecurityException e) {
            textViewAddress.setText("Address: Permission error");
            e.printStackTrace();
        } catch (Exception e) {
            textViewAddress.setText("Address: Unable to start location");
            e.printStackTrace();
        }
    }

    private void showLocationAddress() {
        textViewLatitude.setText("Latitude: " + latitude);
        textViewLongitude.setText("Longitude: " + longitude);

        if (!Geocoder.isPresent()) {
            textViewAddress.setText("Address: Geocoder not available");
            return;
        }

        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);

            if (addresses != null && !addresses.isEmpty()) {
                Address addr = addresses.get(0);
                StringBuilder builder = new StringBuilder("Address: ");

                if (addr.getMaxAddressLineIndex() >= 0) {
                    for (int i = 0; i <= addr.getMaxAddressLineIndex(); i++) {
                        builder.append(addr.getAddressLine(i));
                        if (i < addr.getMaxAddressLineIndex()) {
                            builder.append("\n");
                        }
                    }
                } else {
                    if (addr.getFeatureName() != null) {
                        builder.append(addr.getFeatureName()).append(", ");
                    }
                    if (addr.getLocality() != null) {
                        builder.append(addr.getLocality()).append(", ");
                    }
                    if (addr.getCountryName() != null) {
                        builder.append(addr.getCountryName());
                    }
                }

                textViewAddress.setText(builder.toString());
            } else {
                textViewAddress.setText("Address: No address found");
            }
        } catch (IOException e) {
            textViewAddress.setText("Address: Service not available");
            e.printStackTrace();
        } catch (Exception e) {
            textViewAddress.setText("Address: Unable to get address");
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_PERMISSION) {
            boolean granted = false;

            for (int result : grantResults) {
                if (result == PackageManager.PERMISSION_GRANTED) {
                    granted = true;
                    break;
                }
            }

            if (granted) {
                startLocationUpdates();
            } else {
                textViewAddress.setText("Address: Location permission denied");
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (locationManager != null && locationListener != null) {
            locationManager.removeUpdates(locationListener);
        }
    }
}